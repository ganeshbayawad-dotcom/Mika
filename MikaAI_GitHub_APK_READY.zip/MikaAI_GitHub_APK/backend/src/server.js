import express from "express";
import dotenv from "dotenv";
dotenv.config();
const app = express(); app.use(express.json({limit:"1mb"}));
const port = process.env.PORT || 3000;
app.get("/health", (_req,res)=>res.json({ok:true}));
app.post("/v1/chat", async (req,res)=>{
  try {
    const key=process.env.OPENAI_API_KEY; if(!key) return res.status(500).json({error:"OPENAI_API_KEY is not configured"});
    const message=String(req.body?.message||"").trim(); if(!message) return res.status(400).json({error:"message is required"});
    const r=await fetch("https://api.openai.com/v1/responses",{method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${key}`},body:JSON.stringify({model:process.env.OPENAI_MODEL||"gpt-5.6-luna",instructions:"You are Mika, a friendly adult anime-style AI assistant. Be helpful, concise, and natural.",input:message})});
    const data=await r.json(); if(!r.ok) return res.status(r.status).json({error:data?.error?.message||"OpenAI request failed"});
    res.json({reply:data.output_text||"Sorry, no reply was generated."});
  } catch(e){res.status(500).json({error:e.message||"Server error"});}
});
app.listen(port,()=>console.log(`Mika backend listening on ${port}`));
