# Mika AI — GitHub Actions APK

This repo is prepared for a GitHub Actions Android debug APK build. GitHub Actions can run the Gradle build and upload the resulting APK as an artifact. Android uses Gradle/AGP to compile and package APKs.

## Phone-only steps
1. Create a new GitHub repository (example: `MikaAI`).
2. Upload **all files and folders from this project** to the repository root.
3. Open **Actions** -> **Build Mika AI APK** -> **Run workflow**.
4. Wait for the green check.
5. Open that workflow run -> **Artifacts** -> `MikaAI-debug-apk` -> download.
6. Extract the ZIP and install `app-debug.apk` on Android.

## Important for real AI
Before building, edit `app/src/main/java/com/mika/ai/MainActivity.kt` and replace `BackendConfig.BASE_URL` with your deployed **HTTPS** backend URL.

Do not put your OpenAI API key in the Android app. Keep it in the backend environment variable `OPENAI_API_KEY`.

The included `backend/` is a Node/Express backend. Deploy it to a service that supports Node.js, set `OPENAI_API_KEY`, and expose HTTPS.

## Current app features
- Mika chat UI
- Voice input using Android speech recognition
- Real backend chat request
- Mika voice reply using Android TextToSpeech
- Blue/pink Mika branding

This workflow builds a **debug APK** for testing. A Play Store/release APK should use a proper release signing key.
