package com.example.mikaai

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

object BackendConfig {
    // Change this to your deployed HTTPS backend URL before building.
    const val BASE_URL = "https://YOUR-BACKEND-DOMAIN.example/"
}

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 12)
            setBackgroundColor(Color.rgb(12, 14, 28))
        }
        val title = TextView(this).apply {
            text = "Mika AI 💙💗"
            textSize = 24f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 14)
        }
        root.addView(title)
        val scroll = ScrollView(this)
        chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(4, 8, 4, 8) }
        scroll.addView(chat)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply {
            hint = "Mika ko message karo..."
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); setSingleLine(false)
            setBackgroundColor(Color.rgb(32,34,52)); setPadding(14,10,14,10)
        }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply { text = "🎙"; setOnClickListener { startVoiceInput() } })
        row.addView(Button(this).apply { text = "Send"; setOnClickListener { sendMessage() } })
        root.addView(row)
        setContentView(root)
        addMessage("Mika", "Hi! 💙💗 Main Mika hoon. Real AI ke liye backend URL configure karo.")
    }

    private fun addMessage(who: String, msg: String) {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 6, 0, 6) }
        wrap.addView(TextView(this).apply { text = who; textSize = 12f; setTextColor(Color.LTGRAY) })
        wrap.addView(TextView(this).apply {
            text = msg; textSize = 16f; setTextColor(Color.WHITE); setPadding(16,12,16,12)
            background = GradientDrawable().apply { cornerRadius = 28f; setColor(if (who == "You") Color.rgb(74,54,120) else Color.rgb(35,39,62)) }
        })
        chat.addView(wrap)
    }

    private fun sendMessage() {
        val msg = input.text.toString().trim(); if (msg.isEmpty()) return
        addMessage("You", msg); input.text.clear()
        thread {
            try {
                val conn = (URL(BackendConfig.BASE_URL.trimEnd('/') + "/v1/chat").openConnection() as HttpURLConnection)
                conn.requestMethod = "POST"; conn.connectTimeout = 15000; conn.readTimeout = 30000; conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(JSONObject().put("message", msg).toString().toByteArray()) }
                val body = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
                val reply = JSONObject(body).optString("reply", JSONObject(body).optString("error", "Request failed"))
                runOnUiThread { addMessage("Mika", reply); speak(reply) }
            } catch (e: Exception) {
                runOnUiThread { addMessage("Mika", "Backend connection error: ${e.message}") }
            }
        }
    }

    private fun speak(text: String) { tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mika") }

    private fun startVoiceInput() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        startActivityForResult(i, 100)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) {
            val r = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (!r.isNullOrEmpty()) { input.setText(r[0]); sendMessage() }
        }
    }
    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) { tts.language = Locale("en", "IN"); tts.setSpeechRate(.98f); tts.setPitch(1.08f) } }
    override fun onDestroy() { tts.stop(); tts.shutdown(); super.onDestroy() }
}
